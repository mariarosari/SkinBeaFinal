from django.shortcuts import render, get_object_or_404
from django.http import Http404

from skin_bea_app.models import Catalog


def index(request):
    return render(request, 'index.html')


def login(request):
    return render(request, 'login.html')

def catalogs(request):
    return render(request, 'catalogs.html')


def catalog(request):
    return render(request, 'catalog.html')