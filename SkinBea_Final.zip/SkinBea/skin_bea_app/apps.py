from django.apps import AppConfig


class SkinBeaAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'skin_bea_app'
