from django.db import models
from ckeditor.fields import RichTextField


# Create your models here.
class User(models.Model):
    name = models.CharField(max_length=50)
    age = models.PositiveIntegerField()
    phone = models.CharField(max_length=15)
    email = models.EmailField(unique=True)
    password = models.TextField()

    def __str__(self):
        return self.name


class Catalog(models.Model):
    SUITABLE_CHOICES = [
        ('normal', 'Normal'),
        ('oily', 'Oily'),
        ('dry', 'Dry'),
        ('combination', 'Combination'),
    ]
    name = models.CharField(max_length=255)
   # price = models.DecimalField(max_digits=10, decimal_places=2)
    category = models.CharField(max_length=255)
    suitable_for_normal = models.BooleanField(default=False)
    suitable_for_oily = models.BooleanField(default=False)
    suitable_for_dry = models.BooleanField(default=False)
    suitable_for_combination = models.BooleanField(default=False)
    description = models.TextField()
    how_to_use = models.TextField()
    ingredients = models.TextField()
    image = models.ImageField(upload_to='static/image_of_catalogs')
    wishlist = models.ManyToManyField('Wishlist', blank=True, related_name='catalogs')

    def __str__(self):
        return self.name


class Article(models.Model):
    title = models.CharField(max_length=255)
    author = models.CharField(max_length=255)
    thumbnail = models.ImageField(upload_to='static/thumbnails_of_articles')
    content = RichTextField()

    def __str__(self):
        return self.title


class Wishlist(models.Model):
    customer_id = models.ForeignKey('User', on_delete=models.CASCADE)
    catalog_id = models.ForeignKey('Catalog', on_delete=models.CASCADE, related_name='wishlists')

    def __str__(self):
        return f'{self.customer_id.name}\'s Wishlist for {self.catalog_id.name}'
