from django.urls import path
from . import views

from .Controllers.User import UserController
from .Controllers.Catalog import CatalogController
from .Controllers.Article import ArticleController

user = UserController()
catalog = CatalogController()
article = ArticleController()

urlpatterns = [
    path("", views.index, name="index"),
    path("register", user.register, name="registration"),
    path("login", user.login, name="login"),
    path("logout", user.logout, name="logout"),

    path("catalogs", catalog.view_all, name="catalogs"),
    path("catalog/<int:catalog_id>", catalog.view_detail, name="catalog"),
    path("wishlist_remove/<int:catalog_id>", catalog.remove_from_wishlist, name="wishlist_remove"),
    path("wishlist_add/<int:catalog_id>", catalog.add_to_wishlist, name="wishlist_add"),

    path("articles", article.view_all , name="articles"),
    path("article/<int:article_id>", article.view_article, name="article"),

    path('about', views.index, name="about")
]