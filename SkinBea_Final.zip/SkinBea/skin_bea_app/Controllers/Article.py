from django.shortcuts import render, get_object_or_404
from ..models import Article

from markdown import  markdown

class ArticleController:

    @staticmethod
    def view_all(request):
        articles = Article.objects.all()
        return render(request, 'articles.html', {
            'articles': articles
        })

    @staticmethod
    def view_article(request, article_id):
        article = get_object_or_404(Article, id=article_id)
        article.content = markdown(article.content)
        return render(request, 'article.html', {
            'article': article
        })
