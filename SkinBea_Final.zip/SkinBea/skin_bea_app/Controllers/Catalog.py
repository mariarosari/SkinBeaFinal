from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from ..models import Catalog
from ..models import Wishlist
from ..models import User


class CatalogController:

    @staticmethod
    def view_all(request):

        wishlists = []

        try:
            user_id = request.session['login_info']['user_id']
            wishlists = Wishlist.objects.all().filter(customer_id=user_id)
        except KeyError:
            pass

        filter_category = request.GET.get('category')
        filter_suitable_for = request.GET.get('suitable_for')

        catalogs = Catalog.objects.all()

        if filter_category and filter_category != "None":
            catalogs = catalogs.filter(category=filter_category)

        if filter_suitable_for and filter_suitable_for == 'normal':
            catalogs = catalogs.filter(suitable_for_normal=True)
        elif filter_suitable_for and filter_suitable_for == 'oily':
            catalogs = catalogs.filter(suitable_for_oily=True)
        elif filter_suitable_for and filter_suitable_for == 'dry':
            catalogs = catalogs.filter(suitable_for_dry=True)
        elif filter_suitable_for and filter_suitable_for == 'combination':
            catalogs = catalogs.filter(suitable_for_combination=True)

        categories = Catalog.objects.values_list('category', flat=True).distinct()
        return render(request, 'catalogs.html', {
            'wishlists': wishlists,
            'catalogs': catalogs,
            'categories': categories,
            'current_category': filter_category,
            'current_suitable_for': filter_suitable_for,
        })

    @staticmethod
    def view_detail(request, catalog_id):
        catalog = get_object_or_404(Catalog, pk=catalog_id)

        wishlists = []
        is_listed_in_wishlist = False
        try:
            user_id = request.session['login_info']['user_id']
            wishlists = Wishlist.objects.all().filter(customer_id=user_id)
            is_listed_in_wishlist = wishlists.filter(catalog_id=catalog.id).exists()
        except KeyError:
            pass

        return render(request, 'catalog.html', {
            'catalog': catalog,
            'wishlists': wishlists,
            'is_listed_in_wishlist': is_listed_in_wishlist
        })

    @staticmethod
    def add_to_wishlist(request, catalog_id):
        user_id = request.session['login_info']['user_id']
        user = User.objects.get(id=user_id)
        catalog = Catalog.objects.get(id=catalog_id)
        wishlist, created = Wishlist.objects.get_or_create(customer_id=user, catalog_id=catalog)
        referer = request.META.get('HTTP_REFERER', None)
        return redirect(referer or '/')

    @staticmethod
    def remove_from_wishlist(request, catalog_id):
        user_id = request.session['login_info']['user_id']
        user = User.objects.get(id=user_id)
        catalog = Catalog.objects.get(id=catalog_id)
        Wishlist.objects.get(customer_id=user, catalog_id=catalog).delete()
        referer = request.META.get('HTTP_REFERER', None)
        return redirect(referer or '/')
