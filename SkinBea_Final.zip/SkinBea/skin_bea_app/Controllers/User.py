from django import forms
from django.contrib.auth import authenticate, login
from django.http import Http404, HttpResponse
from django.shortcuts import redirect, render

from ..models import User


class UserCreationForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['name', 'age', 'phone', 'email', 'password']
        widgets = {
            'password': forms.PasswordInput(),
        }


class UserController:

    @staticmethod
    def register(request):
        if request.method == 'POST':
            form = UserCreationForm(request.POST)
            if form.is_valid():
                form.save()
                return redirect('login')
            else:
                return redirect('registration')

        elif request.method == 'GET':
            return render(request, 'registration.html')
        else:
            return Http404('Page Not Found')

    @staticmethod
    def login(request):
        if request.method == 'POST':
            email = request.POST.get('email')
            password = request.POST.get('password')

            # Lakukan otentikasi user
            user = User.objects.filter(email=email, password=password).first()

            if user is not None:
                request.session['login_info'] = {
                    'email': user.email,
                    'user_id': user.id,
                    'user_name' : user.name
                }
                return redirect('index')
            else:
                request.session['failed'] = 'Login Failed! Please check your email address and password!'
                return redirect('login')

        elif request.method == 'GET':
            return render(request, 'login.html')

    @staticmethod
    def logout(request):
        if 'login_info' in request.session:
            del request.session['login_info']
        return redirect('index')
