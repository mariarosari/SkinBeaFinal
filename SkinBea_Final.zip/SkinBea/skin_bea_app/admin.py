from django.contrib import admin

from skin_bea_app.models import User, Catalog, Article, Wishlist
# Register your models here.

admin.site.register(User)
admin.site.register(Article)
admin.site.register(Wishlist)
admin.site.register(Catalog)
